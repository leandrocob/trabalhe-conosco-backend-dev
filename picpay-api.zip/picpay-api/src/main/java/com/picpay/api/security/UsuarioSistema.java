package com.picpay.api.security;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import com.picpay.api.model.UsuarioLogin;

public class UsuarioSistema extends User {

	private static final long serialVersionUID = 1L;

	private UsuarioLogin usuarioLogin;

	public UsuarioSistema(UsuarioLogin usuarioLogin, Collection<? extends GrantedAuthority> authorities) {
		super(usuarioLogin.getEmail(), usuarioLogin.getSenha(), authorities);
		this.usuarioLogin = usuarioLogin;
	}

	public UsuarioLogin getUsuarioLogin() {
		return usuarioLogin;
	}

}
