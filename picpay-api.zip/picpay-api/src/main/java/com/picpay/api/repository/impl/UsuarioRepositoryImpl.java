package com.picpay.api.repository.impl;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.picpay.api.model.Usuario;
import com.picpay.api.model.Usuario_;
import com.picpay.api.repository.UsuarioRepository;

@Repository
public class UsuarioRepositoryImpl implements UsuarioRepository {
	
	@PersistenceContext
	private EntityManager manager;
	
	@Override
	public Page<Usuario> filtrar(String nome, Pageable pageable) throws IOException { 
		
		CriteriaBuilder builder = manager.getCriteriaBuilder();
		CriteriaQuery<Usuario> criteria = builder.createQuery(Usuario.class);
		Root<Usuario> root = criteria.from(Usuario.class);

		List<Predicate> predicates = new ArrayList<>();
		
		if (!StringUtils.isEmpty(nome)) {
			predicates.add(builder.or(builder.like(builder.lower(root.get(Usuario_.nome)), "%" + nome.toLowerCase() + "%"),
									  builder.like(builder.lower(root.get(Usuario_.username)), "%" + nome.toLowerCase() + "%")));
		}

		criteria.where(predicates.toArray(new Predicate[predicates.size()]));
		
		TypedQuery<Usuario> query = manager.createQuery(criteria);
		List<Usuario> usuarios = query.getResultList();
		
		List<String> lista1 = Files.lines(Paths.get("lista_relevancia_1.txt")).collect(Collectors.toList());
		List<String> lista2 = Files.lines(Paths.get("lista_relevancia_2.txt")).collect(Collectors.toList());
		
		LinkedHashMap<Integer, Usuario> prioridade1 = usuarios.stream()
				.filter(usr -> lista1.contains(usr.getId()))
				.collect(Collectors.toMap(s -> s.hashCode(), s -> s,
					                        (e1, e2) -> e1,
					                        LinkedHashMap::new));
		
		LinkedHashMap<Integer, Usuario> prioridade2 = usuarios.stream()
				.filter(usr -> lista2.contains(usr.getId()))
				.collect(Collectors.toMap(s -> s.hashCode(), s -> s,
                        (e1, e2) -> e1,
                        LinkedHashMap::new));
		
		LinkedHashMap<Integer, Usuario> semPrioridade = usuarios.stream()
				.filter(usr -> !lista1.contains(usr.getId()) && !lista2.contains(usr.getId()))
				.collect(Collectors.toMap(s -> s.hashCode(), s -> s,
                        (e1, e2) -> e1,
                        LinkedHashMap::new));
		
		LinkedHashMap<Integer, Usuario> listaUsuarios = new LinkedHashMap<>();
		listaUsuarios.putAll(prioridade1);
		listaUsuarios.putAll(prioridade2);
		listaUsuarios.putAll(semPrioridade);
		
		ArrayList<Usuario> listagem = new ArrayList<Usuario>(listaUsuarios.values());
		
		int start = (int) pageable.getOffset();
		int end = (start + pageable.getPageSize()) > listagem.size() ? listagem.size() : (start + pageable.getPageSize());
		
		return new PageImpl<>(listagem.subList(start, end), pageable, listaUsuarios.size());
	}
	
}
