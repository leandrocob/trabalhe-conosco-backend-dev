package com.picpay.api.repository;

import java.io.IOException;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.picpay.api.model.Usuario;

public interface UsuarioRepository {
	
	public Page<Usuario> filtrar(String nome, Pageable pageable) throws IOException;
	
}
