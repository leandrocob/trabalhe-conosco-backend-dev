package com.picpay.api.repository;

import java.util.Optional;

import com.picpay.api.model.UsuarioLogin;

public interface UsuarioLoginRepository {

	public Optional<UsuarioLogin> buscarLogin(String email);
	
}
