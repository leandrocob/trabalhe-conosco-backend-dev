package com.picpay.api.repository.impl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.picpay.api.model.Permissao;
import com.picpay.api.model.UsuarioLogin;
import com.picpay.api.repository.UsuarioLoginRepository;

@Repository
public class UsuarioLoginRepositoryImpl implements UsuarioLoginRepository {
	
	public Optional<UsuarioLogin> buscarLogin(String email) { 
		
		try {
			List<UsuarioLogin> listaUsuario = Files.lines(Paths.get("usuarioLogin.txt"))
			.map(linha -> linha.split(";"))
			.map(item -> new UsuarioLogin(item[0],item[1],item[2],item[3]))
			.collect(Collectors.toList());
			
			listaUsuario.get(0).setPermissoes(Files.lines(Paths.get("usuarioLogin.txt"))
			.map(linha -> linha.split(";"))
			.map(linha -> linha[4].split("-"))
			.map(item -> new Permissao(item[0],item[1]))
			.collect(Collectors.toList()));
			
			Optional<UsuarioLogin> usuarioLogin = Optional.of(listaUsuario.get(0));
			
			return usuarioLogin;
		} catch (IOException e) {
			e.printStackTrace();
			return Optional.empty();
		}		
	}
}
