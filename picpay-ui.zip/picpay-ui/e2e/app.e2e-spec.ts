import { PicPayUiPage } from './app.po';

describe('algamoney-ui App', () => {
  let page: PicPayUiPage;

  beforeEach(() => {
    page = new PicPayUiPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
